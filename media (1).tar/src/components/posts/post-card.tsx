'use client'

import { formatDistanceToNow } from 'date-fns'
import { id } from 'date-fns/locale'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Heart, MessageCircle, Share2, MoreHorizontal } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import Link from 'next/link'
import { useSession } from 'next-auth/react'

interface PostCardProps {
  post: {
    id: string
    title: string
    content: string | null
    coverImage: string | null
    createdAt: string
    author: {
      id: string
      name: string | null
      username: string | null
      image: string | null
    }
    likes: {
      userId: string
    }[]
    _count: {
      likes: number
    }
  }
}

export function PostCard({ post }: PostCardProps) {
  const { data: session } = useSession()
  const isLiked = session?.user?.id && post.likes.some(like => like.userId === session.user.id)
  const isAuthor = session?.user?.id === post.author.id

  const handleLike = async () => {
    if (!session?.user?.id) return

    try {
      if (isLiked) {
        await fetch(`/api/likes?postId=${post.id}`, {
          method: 'DELETE',
        })
      } else {
        await fetch('/api/likes', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ postId: post.id }),
        })
      }
      window.location.reload()
    } catch (error) {
      console.error('Error liking post:', error)
    }
  }

  return (
    <Card className="overflow-hidden">
      {post.coverImage && (
        <div className="aspect-video w-full overflow-hidden bg-muted">
          <img
            src={post.coverImage}
            alt={post.title}
            className="h-full w-full object-cover"
          />
        </div>
      )}

      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={post.author.image || undefined} />
              <AvatarFallback>
                {post.author.name?.charAt(0) || post.author.username?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">
                {post.author.name || post.author.username || 'Anonymous'}
              </p>
              <p className="text-sm text-muted-foreground">
                @{post.author.username || 'anonymous'} ·{' '}
                {formatDistanceToNow(new Date(post.createdAt), {
                  addSuffix: true,
                  locale: id,
                })}
              </p>
            </div>
          </div>

          {isAuthor && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href={`/posts/${post.id}/edit`}>Edit</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-2">
        <Link href={`/posts/${post.id}`}>
          <h3 className="text-xl font-bold hover:text-primary transition-colors">
            {post.title}
          </h3>
        </Link>
        {post.content && (
          <p className="text-muted-foreground line-clamp-3">
            {post.content}
          </p>
        )}
      </CardContent>

      <CardFooter className="gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLike}
          className={isLiked ? 'text-red-500 hover:text-red-600' : ''}
        >
          <Heart className={`h-4 w-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
          {post._count.likes}
        </Button>
        <Button variant="ghost" size="sm" asChild>
          <Link href={`/posts/${post.id}`}>
            <MessageCircle className="h-4 w-4 mr-2" />
            Komentar
          </Link>
        </Button>
        <Button variant="ghost" size="sm">
          <Share2 className="h-4 w-4 mr-2" />
          Bagikan
        </Button>
      </CardFooter>
    </Card>
  )
}
