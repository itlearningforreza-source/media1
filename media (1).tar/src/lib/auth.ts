import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { db } from "./db"

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        name: { label: "Name", type: "text", optional: true },
        username: { label: "Username", type: "text", optional: true },
      },
      async authorize(credentials) {
        console.log("[AUTH] Starting authorization")

        if (!credentials?.email || !credentials?.password) {
          throw new Error("Email dan password wajib diisi")
        }

        try {
          const user = await db.user.findUnique({
            where: { email: credentials.email },
          })

          if (user) {
            console.log("[AUTH] User exists:", user.email)
            
            if (!user.password) {
              console.log("[AUTH] User has no password")
              throw new Error("Akun ini bermasalah. Silakan daftar ulang.")
            }

            console.log("[AUTH] Checking password")
            console.log("[AUTH] Stored password:", user.password)
            console.log("[AUTH] Input password:", credentials.password)
            console.log("[AUTH] Match:", user.password === credentials.password)

            if (user.password !== credentials.password) {
              throw new Error("Password salah. Periksa kembali password Anda.")
            }

            console.log("[AUTH] Login successful")
            return {
              id: user.id,
              email: user.email,
              name: user.name,
              username: user.username,
              image: user.image,
            }
          } else {
            console.log("[AUTH] User not found, creating new user")
            
            if (!credentials.name) {
              throw new Error("Nama wajib diisi untuk pendaftaran")
            }

            const username = credentials.username || credentials.email.split("@")[0]

            const newUser = await db.user.create({
              data: {
                email: credentials.email,
                name: credentials.name,
                username: username,
                password: credentials.password,
              },
            })

            console.log("[AUTH] User created:", newUser.id)
            return {
              id: newUser.id,
              email: newUser.email,
              name: newUser.name,
              username: newUser.username,
              image: newUser.image,
            }
          }
        } catch (error: any) {
          console.error("[AUTH] Error:", error)
          
          if (error.code === 'P2002') {
            throw new Error("Username sudah digunakan. Pilih username lain.")
          }
          
          throw error
        }
      },
    }),
  ],
  pages: {
    signIn: "/auth/signin",
  },
  session: {
    strategy: "jwt",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.username = (user as any).username
      }
      return token
    },
    async session({ session, token }) {
      if (session?.user) {
        (session.user as any).id = token.id
        (session.user as any).username = token.username
      }
      return session
    },
  },
}
