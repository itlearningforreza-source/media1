'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, UserPlus, UserMinus, MapPin, Link as LinkIcon, Calendar } from 'lucide-react'
import Link from 'next/link'
import { PostCard } from '@/components/posts/post-card'
import { formatDistanceToNow } from 'date-fns'
import { id } from 'date-fns/locale'
import { toast } from 'sonner'

export default function ProfilePage({ params }: { params: { username: string } }) {
  const { data: session } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [followLoading, setFollowLoading] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [posts, setPosts] = useState<any[]>([])
  const [followers, setFollowers] = useState<any[]>([])
  const [following, setFollowing] = useState<any[]>([])
  const [isFollowing, setIsFollowing] = useState(false)

  useEffect(() => {
    fetchProfile()
  }, [params.username])

  const fetchProfile = async () => {
    try {
      setLoading(true)

      const [userRes, postsRes] = await Promise.all([
        fetch(`/api/users/by-username/${params.username}`),
        fetch(`/api/posts?userId=${user?.id || ''}`),
      ])

      if (userRes.ok) {
        const userData = await userRes.json()
        setUser(userData)

        if (userData.id) {
          const postsData = await fetch(`/api/posts?userId=${userData.id}`)
          if (postsData.ok) {
            setPosts(await postsData.json())
          }

          const followersData = await fetch(`/api/follow/${userData.id}?type=followers`)
          if (followersData.ok) {
            const followersJson = await followersData.json()
            setFollowers(followersJson.users || [])
          }

          const followingData = await fetch(`/api/follow/${userData.id}?type=following`)
          if (followingData.ok) {
            const followingJson = await followingData.json()
            setFollowing(followingJson.users || [])
          }

          if (session?.user?.id) {
            const followCheckRes = await fetch(`/api/follow/check?targetUserId=${userData.id}`)
            if (followCheckRes.ok) {
              const checkData = await followCheckRes.json()
              setIsFollowing(checkData.isFollowing || false)
            }
          }
        }
      } else {
        router.push('/')
      }
    } catch (error) {
      console.error('Error fetching profile:', error)
      router.push('/')
    } finally {
      setLoading(false)
    }
  }

  const handleFollow = async () => {
    if (!session?.user?.id) {
      router.push('/auth/signin')
      return
    }

    setFollowLoading(true)

    try {
      if (isFollowing) {
        await fetch(`/api/follow?followingId=${user.id}`, {
          method: 'DELETE',
        })
        toast.success('Berhenti mengikuti')
        setIsFollowing(false)
        setFollowers(prev => prev.filter(f => f.id !== session.user.id))
      } else {
        await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ followingId: user.id }),
        })
        toast.success('Berhasil mengikuti')
        setIsFollowing(true)
        if (session.user) {
          setFollowers(prev => [...prev, session.user])
        }
      }
    } catch (error) {
      toast.error('Gagal mengikuti')
    } finally {
      setFollowLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Memuat...</div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Pengguna tidak ditemukan</div>
      </div>
    )
  }

  const isOwnProfile = session?.user?.id === user.id

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto max-w-4xl px-4 h-14 flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div className="font-semibold">Profil</div>
        </div>
      </header>

      <main className="container mx-auto max-w-4xl px-4 py-6">
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <Avatar className="h-24 w-24 md:h-32 md:w-32">
                  <AvatarImage src={user.image || undefined} />
                  <AvatarFallback className="text-3xl">
                    {user.name?.charAt(0) || user.username?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h1 className="text-2xl font-bold">
                        {user.name || 'Anonymous'}
                      </h1>
                      <p className="text-muted-foreground">@{user.username || 'anonymous'}</p>
                    </div>

                    {!isOwnProfile && session?.user?.id && (
                      <Button
                        variant={isFollowing ? 'outline' : 'default'}
                        onClick={handleFollow}
                        disabled={followLoading}
                      >
                        {isFollowing ? (
                          <>
                            <UserMinus className="mr-2 h-4 w-4" />
                            {followLoading ? 'Memproses...' : 'Berhenti Ikuti'}
                          </>
                        ) : (
                          <>
                            <UserPlus className="mr-2 h-4 w-4" />
                            {followLoading ? 'Memproses...' : 'Ikuti'}
                          </>
                        )}
                      </Button>
                    )}
                  </div>

                  {user.bio && (
                    <p className="text-muted-foreground">{user.bio}</p>
                  )}

                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Bergabung {formatDistanceToNow(new Date(user.createdAt), {
                        addSuffix: true,
                        locale: id,
                      })}
                    </div>
                  </div>

                  <div className="flex gap-6">
                    <div>
                      <span className="font-bold">{posts.length}</span>
                      <span className="text-muted-foreground ml-1">Tulisan</span>
                    </div>
                    <div>
                      <span className="font-bold">{followers.length}</span>
                      <span className="text-muted-foreground ml-1">Pengikut</span>
                    </div>
                    <div>
                      <span className="font-bold">{following.length}</span>
                      <span className="text-muted-foreground ml-1">Mengikuti</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="posts" className="w-full">
            <TabsList>
              <TabsTrigger value="posts">Tulisan</TabsTrigger>
              <TabsTrigger value="followers">Pengikut</TabsTrigger>
              <TabsTrigger value="following">Mengikuti</TabsTrigger>
            </TabsList>

            <TabsContent value="posts" className="space-y-6">
              {posts.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">
                    {isOwnProfile ? 'Anda belum membuat tulisan' : 'Belum ada tulisan'}
                  </p>
                </div>
              ) : (
                posts.map((post) => <PostCard key={post.id} post={post} />)
              )}
            </TabsContent>

            <TabsContent value="followers" className="space-y-4">
              {followers.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Belum ada pengikut</p>
                </div>
              ) : (
                followers.map((follower) => (
                  <Card key={follower.id}>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={follower.image || undefined} />
                          <AvatarFallback>
                            {follower.name?.charAt(0) || follower.username?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{follower.name || 'Anonymous'}</p>
                          <p className="text-sm text-muted-foreground">@{follower.username || 'anonymous'}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/profile/${follower.username}`}>Lihat</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="following" className="space-y-4">
              {following.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Belum mengikuti siapapun</p>
                </div>
              ) : (
                following.map((follow) => (
                  <Card key={follow.id}>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={follow.image || undefined} />
                          <AvatarFallback>
                            {follow.name?.charAt(0) || follow.username?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{follow.name || 'Anonymous'}</p>
                          <p className="text-sm text-muted-foreground">@{follow.username || 'anonymous'}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/profile/${follow.username}`}>Lihat</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
