import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

// GET /api/follow/[userId] - Get followers or following list for a user
export async function GET(
  request: NextRequest,
  { params }: { params: { userId: string } }
) {
  try {
    const searchParams = request.nextUrl.searchParams
    const type = searchParams.get("type") // "followers" or "following"

    if (!type || (type !== "followers" && type !== "following")) {
      return NextResponse.json(
        { error: "Type must be 'followers' or 'following'" },
        { status: 400 }
      )
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: params.userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      )
    }

    if (type === "followers") {
      // Get people who follow this user
      const followers = await db.follow.findMany({
        where: { followingId: params.userId },
        include: {
          follower: {
            select: {
              id: true,
              name: true,
              username: true,
              image: true,
              bio: true,
            },
          },
        },
        orderBy: {
          createdAt: "desc",
        },
      })

      const followerList = followers.map(f => f.follower)

      return NextResponse.json({
        count: followerList.length,
        users: followerList,
      })
    } else {
      // Get people this user follows
      const following = await db.follow.findMany({
        where: { followerId: params.userId },
        include: {
          following: {
            select: {
              id: true,
              name: true,
              username: true,
              image: true,
              bio: true,
            },
          },
        },
        orderBy: {
          createdAt: "desc",
        },
      })

      const followingList = following.map(f => f.following)

      return NextResponse.json({
        count: followingList.length,
        users: followingList,
      })
    }
  } catch (error) {
    console.error("Error fetching follow data:", error)
    return NextResponse.json(
      { error: "Failed to fetch follow data" },
      { status: 500 }
    )
  }
}
