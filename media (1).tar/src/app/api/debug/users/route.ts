import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET() {
  try {
    const users = await db.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        username: true,
        password: true,
        createdAt: true,
      },
    })

    return NextResponse.json({
      count: users.length,
      users: users.map(u => ({
        id: u.id,
        email: u.email,
        name: u.name,
        username: u.username,
        hasPassword: !!u.password,
        passwordLength: u.password?.length || 0,
        createdAt: u.createdAt,
      })),
    })
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    )
  }
}
