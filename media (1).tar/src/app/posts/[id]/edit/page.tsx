'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Save } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

export default function EditPostPage({ params }: { params: { id: string } }) {
  const { data: session } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [fetchLoading, setFetchLoading] = useState(true)

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    coverImage: '',
    published: false,
  })

  useEffect(() => {
    fetchPost()
  }, [params.id])

  const fetchPost = async () => {
    try {
      const response = await fetch(`/api/posts/${params.id}`)
      if (response.ok) {
        const data = await response.json()

        if (data.author.id !== session?.user?.id) {
          router.push('/')
          return
        }

        setFormData({
          title: data.title,
          content: data.content || '',
          coverImage: data.coverImage || '',
          published: data.published,
        })
      } else {
        router.push('/')
      }
    } catch (error) {
      console.error('Error fetching post:', error)
      router.push('/')
    } finally {
      setFetchLoading(false)
    }
  }

  const handleSubmit = async () => {
    if (!formData.title.trim()) {
      toast.error('Judul tidak boleh kosong')
      return
    }

    setLoading(true)

    try {
      const response = await fetch(`/api/posts/${params.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: formData.title,
          content: formData.content,
          coverImage: formData.coverImage || null,
          published: formData.published,
        }),
      })

      if (response.ok) {
        toast.success('Tulisan berhasil diperbarui!')
        router.push(`/posts/${params.id}`)
      } else {
        const error = await response.json()
        toast.error('Gagal memperbarui tulisan', {
          description: error.error || 'Terjadi kesalahan',
        })
      }
    } catch (error) {
      toast.error('Gagal memperbarui tulisan', {
        description: 'Terjadi kesalahan jaringan',
      })
    } finally {
      setLoading(false)
    }
  }

  if (fetchLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Memuat...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto max-w-4xl px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href={`/posts/${params.id}`}>
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <h1 className="text-xl font-bold">Edit Tulisan</h1>
          </div>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="mr-2 h-4 w-4" />
            {loading ? 'Menyimpan...' : 'Simpan Perubahan'}
          </Button>
        </div>
      </header>

      <main className="container mx-auto max-w-4xl px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Edit Tulisan</CardTitle>
              <CardDescription>
                Perbarui tulisanmu dengan perubahan terbaru
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Judul</Label>
                <Input
                  id="title"
                  placeholder="Judul tulisan yang menarik..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverImage">URL Gambar Sampul (Opsional)</Label>
                <Input
                  id="coverImage"
                  placeholder="https://example.com/image.jpg"
                  value={formData.coverImage}
                  onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Konten</Label>
                <Textarea
                  id="content"
                  placeholder="Tulis sesuatu yang menarik..."
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={12}
                  className="resize-none"
                  disabled={loading}
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="published"
                  checked={formData.published}
                  onChange={(e) => setFormData({ ...formData, published: e.target.checked })}
                  disabled={loading}
                  className="rounded"
                />
                <Label htmlFor="published" className="cursor-pointer">
                  Publikasikan tulisan ini
                </Label>
              </div>

              {formData.coverImage && (
                <div className="border rounded-lg overflow-hidden">
                  <img
                    src={formData.coverImage}
                    alt="Preview"
                    className="w-full max-h-64 object-cover"
                    onError={() => setFormData({ ...formData, coverImage: '' })}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
