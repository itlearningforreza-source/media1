'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { formatDistanceToNow } from 'date-fns'
import { id } from 'date-fns/locale'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { ArrowLeft, Heart, MessageCircle, Share2, MoreHorizontal } from 'lucide-react'
import Link from 'next/link'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Separator } from '@/components/ui/separator'

export default function PostDetailPage({ params }: { params: { id: string } }) {
  const { data: session } = useSession()
  const router = useRouter()
  const [post, setPost] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPost()
  }, [params.id])

  const fetchPost = async () => {
    try {
      const response = await fetch(`/api/posts/${params.id}`)
      if (response.ok) {
        const data = await response.json()
        setPost(data)
      } else {
        router.push('/')
      }
    } catch (error) {
      console.error('Error fetching post:', error)
      router.push('/')
    } finally {
      setLoading(false)
    }
  }

  const handleLike = async () => {
    if (!session?.user?.id) {
      router.push('/auth/signin')
      return
    }

    try {
      const isLiked = post.likes.some((like: any) => like.userId === session.user.id)

      if (isLiked) {
        await fetch(`/api/likes?postId=${post.id}`, {
          method: 'DELETE',
        })
      } else {
        await fetch('/api/likes', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ postId: post.id }),
        })
      }
      fetchPost()
    } catch (error) {
      console.error('Error liking post:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Memuat...</div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Tulisan tidak ditemukan</div>
      </div>
    )
  }

  const isAuthor = session?.user?.id === post.author.id
  const isLiked = session?.user?.id && post.likes.some((like: any) => like.userId === session.user.id)

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto max-w-4xl px-4 h-14 flex items-center justify-between">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={handleLike}>
              <Heart className={`h-5 w-5 ${isLiked ? 'fill-current text-red-500' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-4xl px-4 py-8">
        <article className="max-w-3xl mx-auto">
          {post.coverImage && (
            <div className="aspect-video w-full rounded-lg overflow-hidden mb-8">
              <img
                src={post.coverImage}
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <h1 className="text-4xl font-bold mb-6">{post.title}</h1>

          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Link href={`/profile/${post.author.username}`}>
                <Avatar>
                  <AvatarImage src={post.author.image || undefined} />
                  <AvatarFallback>
                    {post.author.name?.charAt(0) || post.author.username?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
              </Link>
              <div>
                <Link href={`/profile/${post.author.username}`}>
                  <p className="font-semibold hover:underline">
                    {post.author.name || post.author.username || 'Anonymous'}
                  </p>
                </Link>
                <p className="text-sm text-muted-foreground">
                  @{post.author.username || 'anonymous'} ·{' '}
                  {formatDistanceToNow(new Date(post.createdAt), {
                    addSuffix: true,
                    locale: id,
                  })}
                </p>
              </div>
            </div>

            {isAuthor && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href={`/posts/${post.id}/edit`}>Edit</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>

          <Separator className="mb-8" />

          {post.content && (
            <div className="prose prose-slate dark:prose-invert max-w-none">
              <p className="whitespace-pre-wrap text-lg leading-relaxed">{post.content}</p>
            </div>
          )}

          <Separator className="my-8" />

          <div className="flex items-center gap-4">
            <Button
              variant={isLiked ? 'default' : 'outline'}
              size="sm"
              onClick={handleLike}
              className={isLiked ? 'bg-red-500 hover:bg-red-600' : ''}
            >
              <Heart className={`mr-2 h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
              {post._count.likes} Suka
            </Button>
            <Button variant="outline" size="sm">
              <MessageCircle className="mr-2 h-4 w-4" />
              Komentar
            </Button>
            <Button variant="outline" size="sm">
              <Share2 className="mr-2 h-4 w-4" />
              Bagikan
            </Button>
          </div>

          {post.likes.length > 0 && (
            <Card className="mt-8">
              <CardHeader>
                <h3 className="font-semibold">Disukai oleh</h3>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  {post.likes.slice(0, 5).map((like: any) => (
                    <Avatar key={like.userId} className="h-8 w-8 border-2 border-background">
                      <AvatarImage src={like.user.image || undefined} />
                      <AvatarFallback>
                        {like.user.name?.charAt(0) || like.user.username?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  ))}
                  {post.likes.length > 5 && (
                    <span className="text-sm text-muted-foreground">
                      dan {post.likes.length - 5} lainnya
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </article>
      </main>
    </div>
  )
}
