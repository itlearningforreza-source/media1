'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

export default function NewPostPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    coverImage: '',
    published: false,
  })

  if (!session) {
    router.push('/auth/signin')
    return null
  }

  const handleSubmit = async (isPublished: boolean = false) => {
    if (!formData.title.trim()) {
      toast.error('Judul tidak boleh kosong')
      return
    }

    setLoading(true)

    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: formData.title,
          content: formData.content,
          coverImage: formData.coverImage || null,
          published: isPublished,
        }),
      })

      if (response.ok) {
        const post = await response.json()
        toast.success(isPublished ? 'Tulisan berhasil dipublikasikan!' : 'Draft tersimpan!')
        router.push(`/posts/${post.id}`)
      } else {
        const error = await response.json()
        toast.error('Gagal menyimpan tulisan', {
          description: error.error || 'Terjadi kesalahan',
        })
      }
    } catch (error) {
      toast.error('Gagal menyimpan tulisan', {
        description: 'Terjadi kesalahan jaringan',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto max-w-4xl px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <h1 className="text-xl font-bold">Buat Tulisan Baru</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => handleSubmit(false)}
              disabled={loading}
            >
              <EyeOff className="mr-2 h-4 w-4" />
              Simpan Draft
            </Button>
            <Button
              onClick={() => handleSubmit(true)}
              disabled={loading}
            >
              <Eye className="mr-2 h-4 w-4" />
              Publikasikan
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-4xl px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Tulisan Baru</CardTitle>
              <CardDescription>
                Bagikan ide dan pemikiranmu dengan komunitas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Judul</Label>
                <Input
                  id="title"
                  placeholder="Judul tulisan yang menarik..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverImage">URL Gambar Sampul (Opsional)</Label>
                <Input
                  id="coverImage"
                  placeholder="https://example.com/image.jpg"
                  value={formData.coverImage}
                  onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Konten</Label>
                <Textarea
                  id="content"
                  placeholder="Tulis sesuatu yang menarik..."
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={12}
                  className="resize-none"
                  disabled={loading}
                />
              </div>

              {formData.coverImage && (
                <div className="border rounded-lg overflow-hidden">
                  <img
                    src={formData.coverImage}
                    alt="Preview"
                    className="w-full max-h-64 object-cover"
                    onError={() => setFormData({ ...formData, coverImage: '' })}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
